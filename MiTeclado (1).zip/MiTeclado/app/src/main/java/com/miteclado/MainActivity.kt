package com.miteclado

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.*

// Pantalla completa (sin ventanas emergentes): guía para activar y fijar el teclado.
class MainActivity : Activity() {
    private lateinit var s1: TextView
    private lateinit var s2: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(48), dp(24), dp(24))
            setBackgroundColor(Color.parseColor("#F7F7FB"))
        }
        fun title(t: String) = TextView(this).apply { text = t; textSize = 26f; setTextColor(Color.BLACK) }
        fun note(t: String) = TextView(this).apply { text = t; textSize = 15f; setTextColor(Color.DKGRAY); setPadding(0, dp(6), 0, dp(14)) }
        fun btn(t: String, a: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; textSize = 17f
            setOnClickListener { a() }
        }

        root.addView(title("Mi Teclado"))
        root.addView(note("Teclado con Copiar, Cortar, Pegar y portapapeles con historial."))

        s1 = note("")
        root.addView(btn("1. Activar teclado") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        root.addView(s1)

        s2 = note("")
        root.addView(btn("2. Predeterminado") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
        root.addView(s2)

        root.addView(note("Importante: Android no tiene un permiso suelto para el portapapeles. " +
            "El acceso se concede al dejar este teclado como predeterminado."))

        root.addView(title("Probar").apply { textSize = 18f })
        root.addView(EditText(this).apply {
            hint = "Escribe aquí para probar el teclado"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3; gravity = Gravity.TOP
        })
        setContentView(ScrollView(this).apply { addView(root); setBackgroundColor(Color.parseColor("#F7F7FB")) })
    }

    override fun onResume() {
        super.onResume()
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        val enabled = imm.enabledInputMethodList.any { it.packageName == packageName }
        val default = (Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: "")
            .startsWith(packageName)
        s1.text = if (enabled) "✅ Activado" else "⬜ Aún no activado"
        s2.text = if (default) "✅ Es tu teclado predeterminado" else "⬜ Aún no es el predeterminado"
    }
}
