package com.miteclado

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.inputmethodservice.InputMethodService
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.*
import org.json.JSONArray

class ClipKeyboardService : InputMethodService() {
    private var shift = false
    private var symbols = false
    private val history = mutableListOf<String>()
    private lateinit var cm: ClipboardManager
    private lateinit var keysBox: LinearLayout
    private lateinit var historyScroll: HorizontalScrollView
    private lateinit var historyRow: LinearLayout

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
        if (!t.isNullOrEmpty()) addHistory(t)
    }

    override fun onCreate() {
        super.onCreate()
        cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val arr = JSONArray(getSharedPreferences("clips", 0).getString("h", "[]"))
        for (i in 0 until arr.length()) history.add(arr.getString(i))
        cm.addPrimaryClipChangedListener(clipListener)
    }

    override fun onDestroy() {
        cm.removePrimaryClipChangedListener(clipListener)
        super.onDestroy()
    }

    private fun addHistory(t: String) {
        history.remove(t); history.add(0, t)
        while (history.size > 30) history.removeAt(history.size - 1)
        getSharedPreferences("clips", 0).edit().putString("h", JSONArray(history).toString()).apply()
        if (::historyRow.isInitialized) renderHistory()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun key(label: String, weight: Float = 1f, bg: String = "#FFFFFF", onClick: () -> Unit) =
        Button(this).apply {
            text = label; isAllCaps = false; textSize = 16f
            setTextColor(Color.BLACK); setBackgroundColor(Color.parseColor(bg))
            minWidth = 0; minimumWidth = 0; setPadding(0, 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, dp(46), weight).apply { setMargins(dp(2), dp(3), dp(2), dp(3)) }
            setOnClickListener { onClick() }
        }

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#E3E5EC"))
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        // Barra de acciones
        val bar = LinearLayout(this)
        bar.addView(key("Copiar", 1f, "#C9E4FF") { doCopy(false) })
        bar.addView(key("Cortar", 1f, "#C9E4FF") { doCopy(true) })
        bar.addView(key("Pegar", 1f, "#CFF5D0") { doPaste() })
        bar.addView(key("Todo", 1f, "#C9E4FF") {
            currentInputConnection?.performContextMenuAction(android.R.id.selectAll)
        })
        bar.addView(key("📋", 1f, "#FFE9B8") {
            historyScroll.visibility = if (historyScroll.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        })
        root.addView(bar)

        historyScroll = HorizontalScrollView(this).apply { visibility = View.GONE }
        historyRow = LinearLayout(this)
        historyScroll.addView(historyRow)
        root.addView(historyScroll)
        renderHistory()

        keysBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(keysBox)
        renderKeys()
        return root
    }

    private fun renderHistory() {
        historyRow.removeAllViews()
        if (history.isEmpty()) {
            historyRow.addView(TextView(this).apply { text = "Aún no has copiado nada"; setPadding(dp(8), dp(8), dp(8), dp(8)) })
            return
        }
        historyRow.addView(Button(this).apply {
            text = "🗑"; setOnClickListener {
                history.clear()
                getSharedPreferences("clips", 0).edit().putString("h", "[]").apply()
                renderHistory()
            }
        })
        history.forEach { t ->
            historyRow.addView(Button(this).apply {
                text = if (t.length > 22) t.take(22).replace("\n", " ") + "…" else t.replace("\n", " ")
                isAllCaps = false
                setOnClickListener { currentInputConnection?.commitText(t, 1) }
            })
        }
    }

    private fun renderKeys() {
        keysBox.removeAllViews()
        val rows = if (symbols) listOf("1234567890", "@#$%&-+()/", "*\"':;!?,.")
                   else listOf("qwertyuiop", "asdfghjklñ", "zxcvbnm")
        rows.forEachIndexed { i, r ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
            if (i == 2 && !symbols) row.addView(key(if (shift) "⬆" else "⇧", 1.4f, "#D0D3DC") {
                shift = !shift; renderKeys()
            })
            r.forEach { c ->
                val ch = if (shift && !symbols) c.uppercaseChar().toString() else c.toString()
                row.addView(key(ch) {
                    currentInputConnection?.commitText(ch, 1)
                    if (shift) { shift = false; renderKeys() }
                })
            }
            if (i == 2) row.addView(key("⌫", 1.4f, "#D0D3DC") { backspace() })
            keysBox.addView(row)
        }
        val last = LinearLayout(this)
        last.addView(key(if (symbols) "ABC" else "123", 1.3f, "#D0D3DC") { symbols = !symbols; renderKeys() })
        last.addView(key(",", 0.8f) { currentInputConnection?.commitText(",", 1) })
        last.addView(key("espacio", 4f) { currentInputConnection?.commitText(" ", 1) })
        last.addView(key(".", 0.8f) { currentInputConnection?.commitText(".", 1) })
        last.addView(key("↵", 1.3f, "#D0D3DC") { enter() })
        keysBox.addView(last)
    }

    private fun backspace() {
        val ic = currentInputConnection ?: return
        if (!ic.getSelectedText(0).isNullOrEmpty()) ic.commitText("", 1) else ic.deleteSurroundingText(1, 0)
    }

    private fun enter() {
        val ic = currentInputConnection ?: return
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
    }

    private fun doCopy(cut: Boolean) {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)?.toString()
        if (sel.isNullOrEmpty()) {
            Toast.makeText(this, "Selecciona texto primero", Toast.LENGTH_SHORT).show(); return
        }
        cm.setPrimaryClip(ClipData.newPlainText("texto", sel))
        addHistory(sel)
        if (cut) ic.commitText("", 1)
        Toast.makeText(this, if (cut) "Cortado" else "Copiado", Toast.LENGTH_SHORT).show()
    }

    private fun doPaste() {
        val t = history.firstOrNull()
            ?: cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
        if (t.isNullOrEmpty()) Toast.makeText(this, "Portapapeles vacío", Toast.LENGTH_SHORT).show()
        else currentInputConnection?.commitText(t, 1)
    }
}
